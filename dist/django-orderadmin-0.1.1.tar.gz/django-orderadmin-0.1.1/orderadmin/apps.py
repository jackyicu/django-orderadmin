from django.apps import AppConfig


class OrderadminConfig(AppConfig):
    name = 'orderadmin'
